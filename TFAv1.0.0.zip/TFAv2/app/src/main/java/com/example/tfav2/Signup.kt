package com.example.tfav2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase



class Signup : AppCompatActivity() {

    lateinit var etUserName: EditText
    lateinit var etEmail: EditText
    lateinit var etConfPass: EditText
    lateinit var etFullName: EditText

    private lateinit var etPass: EditText
    private lateinit var btnSignup: Button
    lateinit var btnRedirectLogin: Button


    private lateinit var auth:FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_signup)

        //binding
        etUserName = findViewById(R.id.edtUsername)
        etPass = findViewById(R.id.edtPassReg)
        etConfPass = findViewById(R.id.edtPassConf)
        etEmail = findViewById(R.id.edtEmail)
        etFullName = findViewById(R.id.edtfullName)
        btnSignup = findViewById(R.id.btnSignUp)
        btnRedirectLogin = findViewById(R.id.btnLoginRedirect)

        auth = Firebase.auth

        btnSignup.setOnClickListener {
            signUpUser()
        }
        btnRedirectLogin.setOnClickListener {
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun signUpUser(){
        val username = etUserName.text.toString()
        val pass = etPass.text.toString()
        val confPass =  etConfPass.text.toString()
        val email = etEmail.text.toString()

        if (email.isBlank() || pass.isBlank() || confPass.isBlank()){
            Toast.makeText(this, "Email and password can't be blank", Toast.LENGTH_SHORT).show()
            return
        }
        if (pass != confPass) {
            Toast.makeText(this, "Password and Confirm password do not match", Toast.LENGTH_SHORT).show()
            return
        }
        //if all creds are correct
        // we call creatUserWithEmailand Password using the auth object and pass the email to pass in it

        auth.createUserWithEmailAndPassword(email,pass).addOnCompleteListener(this){
            if (it.isSuccessful){
//                Toast.makeText(this, "Successfully Signed Up", Toast.LENGTH_SHORT).show()
                login()
                finish()
            }
            else {
                Toast.makeText(this, "Signed Up Failed!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun login() {
        val intent = Intent(this, Login::class.java)
        startActivity(intent)
    }
}