package com.example.tfav2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.content.Intent
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth

class Login : AppCompatActivity() {

    private lateinit var tvRedirectSignUp: TextView
    lateinit var etEmail: EditText
    private lateinit var etPass: EditText
    lateinit var btnLogin: Button

    lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        tvRedirectSignUp  = findViewById(R.id.tvRedirectSignup)
        btnLogin = findViewById(R.id.btnLogin)
        etEmail = findViewById(R.id.edtEmail)
        etPass = findViewById(R.id.edtPassword)

        auth = FirebaseAuth.getInstance()

        btnLogin.setOnClickListener {
            login()
        }
        tvRedirectSignUp.setOnClickListener{
            val intent = Intent(this, Signup::class.java)
            startActivity(intent)
            finish()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


    }

    private fun login() {
        val email = etEmail.text.toString()
        val pass = etPass.text.toString()
        //calling signInWithEmailPassword(email, pass)
        //function using Firebase auth object
        //On successful response Display a Toast
       auth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(this) {
           if (it.isSuccessful){
               Toast.makeText(this, "Successfully LoggedIn", Toast.LENGTH_SHORT).show()
               openHome()
           }
           else
               Toast.makeText(this, "Log In failed ", Toast.LENGTH_SHORT).show()
       }
    }

    private fun openHome() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

}